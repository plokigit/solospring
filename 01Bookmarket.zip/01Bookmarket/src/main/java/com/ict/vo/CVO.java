package com.ict.vo;

public class CVO {
		private String c_idx, p_num, p_name, p_price, p_saleprice, amount, id ;
		
		// getter/setter
		public String getC_idx() {
			return c_idx;
		}

		public void setC_idx(String c_idx) {
			this.c_idx = c_idx;
		}

		public String getP_num() {
			return p_num;
		}

		public void setP_num(String p_num) {
			this.p_num = p_num;
		}

		public String getP_name() {
			return p_name;
		}

		public void setP_name(String p_name) {
			this.p_name = p_name;
		}

		public String getP_price() {
			return p_price;
		}

		public void setP_price(String p_price) {
			this.p_price = p_price;
		}

		public String getP_saleprice() {
			return p_saleprice;
		}

		public void setP_saleprice(String p_saleprice) {
			this.p_saleprice = p_saleprice;
		}

		public String getAmount() {
			return amount;
		}

		public void setAmount(String amount) {
			this.amount = amount;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}
		
}
